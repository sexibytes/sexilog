package ExampleModule;

use strict;
use warnings;

# This is an example module used by Test::MockModule for testing.

sub Vars {
	return;
}

sub param {
	return;
}

1;